package BDDCucumber.IntroductionToBDD;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
@RunWith(Cucumber.class)
@CucumberOptions(
		features="/Users/SA20463801/eclipse-workspace/guru99pbl/src/main/java/BDDCucumber/IntroductionToBDD/LinkedINSignUp.feature"
		,glue= {"BDDCucumber.IntroductionToBDD"}
		)

public class Runner_LinkedinSignup {
	

}
